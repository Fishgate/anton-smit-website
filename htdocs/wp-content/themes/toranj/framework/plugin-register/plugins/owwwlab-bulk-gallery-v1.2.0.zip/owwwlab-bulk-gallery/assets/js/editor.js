
;(function($){
    $(function(){
        // Close the modal window on user action.
        var owlabbulkg_trigger_target  = owlabbulkg_editor_frame = false;
        var owlabbulkg_append_and_hide = function(e){
            e.preventDefault();
            $('.owlabbulkg-default-ui .selected').removeClass('details selected');
            $('.owlabbulkg-default-ui').appendTo('.owlabbulkg-default-ui-wrapper').hide();
            owlabbulkg_trigger_target = owlabbulkg_editor_frame = false;
        };

        $(document).on('click', '.owlabbulkg-choose-slider, .owlabbulkg-modal-trigger', function(e){
            e.preventDefault();

            // Store the trigger target.
            owlabbulkg_trigger_target = e.target;

            // Show the modal.
            owlabbulkg_editor_frame = true;
            $('.owlabbulkg-default-ui').appendTo('body').show();

            $(document).on('click', '.media-modal-close, .media-modal-backdrop, .owlabbulkg-cancel-insertion', owlabbulkg_append_and_hide);
            $(document).on('keydown', function(e){
                if ( 27 == e.keyCode && owlabbulkg_editor_frame ) {
                    owlabbulkg_append_and_hide(e);
                }
            });
        });

        $(document).on('click', '.owlabbulkg-default-ui .thumbnail, .owlabbulkg-default-ui .check, .owlabbulkg-default-ui .media-modal-icon', function(e){
            e.preventDefault();
            if ( $(this).parent().parent().hasClass('selected') ) {
                $(this).parent().parent().removeClass('details selected');
                $('.owlabbulkg-insert-slider').attr('disabled', 'disabled');
            } else {
                $(this).parent().parent().parent().find('.selected').removeClass('details selected');
                $(this).parent().parent().addClass('details selected');
                $('.owlabbulkg-insert-slider').removeAttr('disabled');
            }
        });

        $(document).on('click', '.owlabbulkg-default-ui .check', function(e){
            e.preventDefault();
            $(this).parent().parent().removeClass('details selected');
            $('.owlabbulkg-insert-slider').attr('disabled', 'disabled');
        });

        $(document).on('click', '.owlabbulkg-default-ui .owlabbulkg-insert-slider', function(e){
            e.preventDefault();

            // Either insert into an editor or make an ajax request.
            if ( $(owlabbulkg_trigger_target).hasClass('owlabbulkg-choose-slider') ) {
                wp.media.editor.insert('[owlabbulkg id="' + $('.owlabbulkg-default-ui .selected').data('owlabbulkg-id') + '"]');
            } else {
                // Make the ajax request.
                var req_data = {
                    action: 'owlabbulkg_load_slider_data',
                    id:     $('.owlabbulkg-default-ui:first .selected').data('owlabbulkg-id')
                };
                $.post(ajaxurl, req_data, function(res){
                    // Trigger the event.
                    $(document).trigger({ type: 'owlabbulkgSliderModalData', slider: res });

                    // Close the modal.
                    owlabbulkg_append_and_hide(e);
                }, 'json');
            }

            // Hide the modal.
            owlabbulkg_append_and_hide(e);
        });
    });
}(jQuery));